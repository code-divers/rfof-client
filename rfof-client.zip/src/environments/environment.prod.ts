export const environment = {
  production: true,
  restApi: 'http://31.168.173.124:20080/api',
  socketApi: 'http://31.168.173.124:20080'
};
