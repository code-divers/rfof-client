import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rfof-cage-status',
  templateUrl: './cage-status.component.html',
  styleUrls: ['./cage-status.component.scss']
})
export class CageStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
