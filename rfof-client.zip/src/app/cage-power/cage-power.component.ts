import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rfof-cage-power',
  templateUrl: './cage-power.component.html',
  styleUrls: ['./cage-power.component.scss']
})
export class CagePowerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
